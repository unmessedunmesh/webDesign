var express = require('express');

var app = express();



app.use(express.static(__dirname + '/dist/boonsupply'));

app.use('/js', express.static(__dirname + '/js'));


app.get('*', function(req, res){
	res.sendfile(__dirname +'/index.html');
})

app.listen(8080);